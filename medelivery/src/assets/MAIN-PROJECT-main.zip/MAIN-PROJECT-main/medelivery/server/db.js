require("dotenv").config();

const { Pool } = require("pg");

const pool = new Pool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT) || 5432,
  user: process.env.DB_USER || "postgres",
  password: process.env.DB_PASSWORD || "leo@16",
  database: process.env.DB_NAME || "medelivery"
});

module.exports = pool;

//What this part of the code does that it connects to postgres database
//